# Command: /pr:assess-news-value

## Description
Evaluate an announcement against professional newsworthiness criteria and produce a clear assessment with recommendations.

## When to Use
Run this as the first step on any new announcement. If news value is weak, address it before investing in press release writing or pitching.

## Instructions

1. Ask the user to provide: a brief description of the announcement, or a draft press release if one exists.

2. Apply the newsworthiness criteria from `pr-strategy.md`:
   - Timeliness
   - Magnitude
   - Novelty
   - Proximity
   - Human interest
   - Conflict/tension

3. Score each dimension: High / Medium / Low with one sentence of rationale.

4. Produce an overall assessment:
   - **Strong**: Pitch broadly, pursue top-tier targets
   - **Moderate**: Pitch selectively, focus on trade and niche outlets most likely to care
   - **Weak**: Identify what would strengthen the story before pitching; recommend holding or reworking

5. Identify the strongest angle — the single most compelling reason a journalist would cover this.

6. Flag any red flags that could undercut coverage even if the story is pitched.

## Output
Deliver a concise news value report (1 page equivalent) with scores, rationale, overall rating, recommended angle, and any flags. Offer to proceed to competitive scan or release review based on the outcome.