# Command: /pr:build-media-list

## Description
Research and build a tiered, scored, prioritized media target list for the announcement.

## Instructions

1. Ask for: announcement topic, target audience profile, geographic scope, preferred coverage types (breaking news / feature / trade / podcast / etc.), any known priority outlets or journalists.

2. Use web search to identify relevant journalists and outlets across the specified beats and platforms.

3. Apply the journalist intelligence framework from `pr-journalist-intel.md`.

4. Run `scripts/journalist_scorer.py` if available to score and rank the list programmatically.

5. Produce the full tiered media list with Tier A deep-dives.

6. Flag any coverage gaps — important beats or outlet types where strong fits couldn't be found.

## Output
Full structured media list organized by tier. Save as a file in the working folder. Offer to proceed to pitch drafting next.
